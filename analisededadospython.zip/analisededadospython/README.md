# analisededadospython
 Projeto de Analise de Dados com python, solucionando um problema rea.l
